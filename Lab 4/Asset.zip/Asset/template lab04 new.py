in_filename = input(......)

try:
    """
    TODO - Task 1
     > Menerima Input
     > Membaca File
     > Menghitung minimum, maksimum, serta range 
       dari karakter pada baris-baris yang ada 
     > Menulis output program file yang sama tanpa 
       menghilangkan isi file yang sebelumnya
    """
    # Tambahkan kode di bawah baris ini
except ......:
	print("File tidak ditemukan :(")

......: # Diisi statement yang dijalankan ketika program berjalan tanpa error
    print(f"Output berhasil ditulis pada {in_filename}")

input("Program selesai. Tekan enter untuk keluar...")
